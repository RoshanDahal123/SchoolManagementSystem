import { baseApi } from "../../app/base-api";
import type {
  CreateTeacherRequest,
  InviteTeacherRequest,
  PaginatedTeachers,
  TeacherAssignmentResponse,
  TeacherHomeroomSection,
  TeacherResponse,
  UpdateTeacherRequest,
} from "./@types";

export const teachersApi = baseApi.injectEndpoints({
  endpoints: (builder) => ({
    getTeachers: builder.query<
      PaginatedTeachers,
      { page: number; search?: string }
    >({
      query: ({ page, search }) => {
        const params = new URLSearchParams({
          page: String(page),
          pageSize: "10",
        });
        if (search?.trim()) {
          params.set("search", search.trim());
        }
        return {
          url: `/teachers?${params.toString()}`,
          method: "GET",
        };
      },
      providesTags: (result) =>
        result
          ? [
              ...result.items.map(({ id }) => ({
                type: "Teacher" as const,
                id,
              })),
              { type: "Teacher", id: "LIST" },
            ]
          : [{ type: "Teacher", id: "LIST" }],
    }),

    getTeacherById: builder.query<TeacherResponse, string>({
      query: (id) => ({ url: `/teachers/${id}`, method: "GET" }),
      providesTags: (_result, _error, id) => [{ type: "Teacher", id }],
    }),
    getAllTeachers: builder.query<TeacherResponse[], void>({
      query: () => ({ url: "/teachers/all", method: "GET" }),
      providesTags: (result) =>
        result
          ? [
              ...result.map(({ id }) => ({ type: "Teacher" as const, id })),
              { type: "Teacher", id: "LIST" },
            ]
          : [{ type: "Teacher", id: "LIST" }],
    }),

    createTeacher: builder.mutation<TeacherResponse, CreateTeacherRequest>({
      query: (body) => ({ url: "/teachers", method: "POST", data: body }),
      invalidatesTags: [{ type: "Teacher", id: "LIST" }, "Dashboard"],
    }),

    updateTeacher: builder.mutation<
      TeacherResponse,
      { id: string; data: UpdateTeacherRequest }
    >({
      query: ({ id, data }) => ({
        url: `/teachers/${id}`,
        method: "PUT",
        data,
      }),
      invalidatesTags: (_result, _error, { id }) => [
        { type: "Teacher", id },
        { type: "Teacher", id: "LIST" },
        "Dashboard",
      ],
    }),

    deactivateTeacher: builder.mutation<void, string>({
      query: (id) => ({
        url: `/teachers/${id}/deactivate`,
        method: "POST",
      }),
      invalidatesTags: (_result, _error, id) => [
        { type: "Teacher", id },
        { type: "Teacher", id: "LIST" },
        "Dashboard",
      ],
    }),

    reactivateTeacher: builder.mutation<void, string>({
      query: (id) => ({
        url: `/teachers/${id}/reactivate`,
        method: "POST",
      }),
      invalidatesTags: (_result, _error, id) => [
        { type: "Teacher", id },
        { type: "Teacher", id: "LIST" },
        "Dashboard",
      ],
    }),

    inviteTeacher: builder.mutation<TeacherResponse, InviteTeacherRequest>({
      query: ({ id, email }) => ({
        url: `/teachers/${id}/invite`,
        method: "POST",
        data: { email },
      }),
      invalidatesTags: (_result, _error, { id }) => [
        { type: "Teacher", id },
        { type: "Teacher", id: "LIST" },
      ],
    }),

    resendTeacherInvite: builder.mutation<void, string>({
      query: (id) => ({
        url: `/teachers/${id}/resend-invite`,
        method: "POST",
      }),
      invalidatesTags: (_result, _error, id) => [
        { type: "Teacher", id },
        { type: "Teacher", id: "LIST" },
      ],
    }),
    getTeacherAssignments: builder.query<TeacherAssignmentResponse[], string>({
      query: (id) => ({ url: `/teachers/${id}/assignments`, method: "GET" }),
      providesTags: (_r, _e, id) => [
        {
          type: "Teacher",
          id: `${id}-ASSIGNMENTS`,
        },
      ],
    }),
    getTeacherHomeroomSections: builder.query<TeacherHomeroomSection[], string>(
      {
        query: (id) => ({
          url: `/teachers/${id}/homeroom-sections`,
          method: "GET",
        }),
        providesTags: (_r, _e, id) => [
          { type: "Teacher", id: `${id}-HOMEROOM` },
        ],
      },
    ),

    getTeacherTeachingSections: builder.query<TeacherHomeroomSection[], string>(
      {
        query: (id) => ({
          url: `/teachers/${id}/teaching-sections`,
          method: "GET",
        }),
        providesTags: (_r, _e, id) => [
          { type: "Teacher", id: `${id}-TEACHING` },
        ],
      },
    ),
  }),

  overrideExisting: false,
});

export const {
  useGetTeachersQuery,
  useGetTeacherByIdQuery,
  useGetAllTeachersQuery,
  useCreateTeacherMutation,
  useUpdateTeacherMutation,
  useDeactivateTeacherMutation,
  useReactivateTeacherMutation,
  useInviteTeacherMutation,
  useResendTeacherInviteMutation,
  useGetTeacherAssignmentsQuery,
  useGetTeacherHomeroomSectionsQuery,
  useGetTeacherTeachingSectionsQuery,
} = teachersApi;
