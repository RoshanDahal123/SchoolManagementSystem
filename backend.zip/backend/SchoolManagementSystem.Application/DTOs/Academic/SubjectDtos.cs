// Application/DTOs/Academic/SubjectDtos.cs
namespace SchoolManagementSystem.Application.DTOs.Academic;

public record SubjectResponse(Guid Id, string Name,bool isActive, string Code, int CreditHours, DateTime CreatedAtUtc);
public record CreateSubjectRequest(string Name, string Code, int CreditHours = 0);
public record UpdateSubjectRequest(string Name, string Code, int CreditHours = 0);
